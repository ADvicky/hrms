
"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";




type SidebarProps = {
  role: string;
  email: string;
};

const links = [
  { name: "Dashboard", href: "/dashboard" },
  { name: "Employees", href: "/employees" },
  { name: "Settings", href: "/settings" },
];

export default function Sidebar({
  role,
  email,
}: SidebarProps) {
  const pathname = usePathname();

  const panel =
    role.charAt(0).toUpperCase() + role.slice(1);

  return (
    <aside className="flex h-full w-64 shrink-0 flex-col border-r border-slate-700 bg-slate-900 p-5 text-slate-200">

      <div className="mb-8 flex items-center justify-center gap-4">
        {/* <SideProfilePicture /> */}

        <h2 className="text-xl font-bold">
          {panel} Panel
        </h2>
      </div>

      <nav className="flex flex-col gap-2">
        {links.map((link) => {
          const isActive = pathname === link.href;

          return (
            <Link
              key={link.href}
              href={link.href}
              aria-current={isActive ? "page" : undefined}
              className={`
                rounded-lg p-3
                transition-all duration-200
                hover:bg-slate-700
                ${
                  isActive
                    ? "outline outline-2 outline-cyan-400 bg-slate-800 text-cyan-400"
                    : "text-white"
                }
              `}
            >
              {link.name}
            </Link>
          );
        })}
      </nav>

      <div className="mt-auto border-t border-slate-600 pt-1">
        <div className="flex items-center justify-between gap-2 text-green-400">
          <span className="min-w-0 truncate text-sm">
            {email}
          </span>

          {/* <LogoutButton /> */}
        </div>
      </div>

    </aside>
  );
}

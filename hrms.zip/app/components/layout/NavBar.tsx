"use client";

import type { Dispatch, SetStateAction } from "react";
import ThemeToggle from "@/app/components/ThemeToggle";
import Image from "next/image";

type NavBarProps = {

  name:string;
  email:string;
};
export default function Navbar({
  
  name,
  email
}: NavBarProps) {

    // const session = await auth()

    
const navname = 
name?.[0] ??
email?.[0] ??
  "U"

    console.log("name",email);

   const displayName = name || email?.split("@")[0] || "";

const emailName = displayName
  ? displayName.charAt(0).toUpperCase() + displayName.slice(1)
  : "User";
    
  return (
    <header className="h-16 bg-white
                       flex items-center justify-between
                       px-6 border-b-2 dark:text-white dark:bg-slate-600">
                        <div className="flex justify-center items-center gap-3">


      <h1 className="text-xl text-black font-semibold dark:text-white dark:bg-slate-600">
        Employee Management
      </h1>
      </div>

      <div className="flex text-black  dark:text-white items-center gap-3">
        <ThemeToggle />
        <span>{emailName}</span>

        <div className="w-9 h-9 rounded-full
                        bg-blue-600 dark:bg-slate-200 dark:text-black text-white
                        flex items-center justify-center">
          {(navname).toUpperCase()}
        </div>
      </div>
    </header>
  );
}
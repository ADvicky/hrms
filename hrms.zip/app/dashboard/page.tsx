import WelcomeSection from "@/app/components/dashboard/WelcomeSection";
import StatsCard from "@/app/components/dashboard/StatsCard";
import AttendanceOverview from "@/app/components/dashboard/AttendanceOverview";
import PayrollOverview from "@/app/components/dashboard/PayrollOverview";
import LeaveApprovals from "@/app/components/dashboard/LeaveApprovals";
import ActiveProjects from "@/app/components/dashboard/ActiveProjects";

export default function DashboardPage() {
  return (
    <main className="space-y-6 p-6">
      <WelcomeSection />

      <section className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatsCard title="Total Employees" value={245} />
        <StatsCard title="Attendance" value="92%" />
        <StatsCard title="On Leave" value={18} />
        <StatsCard title="Pending Approvals" value={7} />
      </section>

      <section className="grid grid-cols-1 gap-6 xl:grid-cols-2">
        <AttendanceOverview />
        <PayrollOverview />
        <LeaveApprovals />
        <ActiveProjects />
      </section>
    </main>
  );
}